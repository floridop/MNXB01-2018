#include "circle.h"

circle::circle(double base, double height) : shape(base, height) {
	
}

circle::~circle() {
	
}
