#include "square.h"

square::square(double base, double height) : rectangle(base, height) {
	
}

square::~square() {
	
}
